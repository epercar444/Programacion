package Examen_Ejercicio1;

public class GuzmanitosExcepcion extends Exception{

	protected GuzmanitosExcepcion(String mensaje) {
		super(mensaje);
	}

}
