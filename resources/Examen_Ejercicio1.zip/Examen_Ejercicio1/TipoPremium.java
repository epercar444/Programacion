package Examen_Ejercicio1;

public enum TipoPremium {
	PREMIUM, PREMIUM_VIP;
}
