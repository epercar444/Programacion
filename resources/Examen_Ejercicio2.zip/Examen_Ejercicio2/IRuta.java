package Examen_Ejercicio2;

public interface IRuta {
	double getCoste();
	String getTipoRuta();
}
